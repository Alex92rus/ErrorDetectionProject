FILENAME = 'fce_train.gold.max.rasp.old_cat.m2'
WINDOWSIZE = 3