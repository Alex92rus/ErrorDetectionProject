hidden layer 1 - 64 
hidden layer 2

Epoch: 2779 cost= 1.024192327
Accuracy: 0.91
Counter({0: 51, 1: 49})
Optimization Finished!
Accuracy: 0.91

